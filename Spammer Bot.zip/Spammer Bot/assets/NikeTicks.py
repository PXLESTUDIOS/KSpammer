import assets.ProgramHelper as Song
import time



Song.play("assets\\NikeTicks.txt")
